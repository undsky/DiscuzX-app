<?php
header('Location: http://addon.discuz.com/?@appbyme_app.plugin.doc/install');



?>