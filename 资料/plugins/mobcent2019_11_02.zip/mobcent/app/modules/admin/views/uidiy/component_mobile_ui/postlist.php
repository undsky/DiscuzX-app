<?php 
/**
 * component_mobile_ui_postlist view
 *
 * @author hongliang
 * @copyright 2012-2014 Appbyme
 */
?>
<div class="content-list-ui">
    <img src="<?php echo $this->rootUrl; ?>/images/admin/tmp/postlist.jpg" style="width:336px;height: 498px;">
</div>