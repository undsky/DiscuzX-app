<?php
/**
 * Created by PhpStorm.
 * User: tantan
 * Date: 16/6/16
 * Time: 14:46
 */
return array(
    '000001' => '传入参数错误',
    '000002' => 'token错误'
);