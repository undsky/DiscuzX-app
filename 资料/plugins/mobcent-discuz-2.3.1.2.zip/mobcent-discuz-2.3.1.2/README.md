mobcent-discuz
==============

安米公司为discuz站转化成app的mobcent接口包

更多详情请访问 http://addon.discuz.com/?@appbyme_app.plugin.doc/install
