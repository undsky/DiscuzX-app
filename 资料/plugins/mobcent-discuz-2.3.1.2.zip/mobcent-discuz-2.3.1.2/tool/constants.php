<?php 
	DEFINE('RESULT', "rs");
	DEFINE('SUCCESS', (int)1);
	DEFINE('FAILED',  (int)0);
	DEFINE('ERROR_CODE', "errcode");
	DEFINE('ERROR', '{"rs":0,"er"}');

?>