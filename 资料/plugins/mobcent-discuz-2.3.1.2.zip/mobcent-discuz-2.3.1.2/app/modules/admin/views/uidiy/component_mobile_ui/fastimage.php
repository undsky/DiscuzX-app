<?php 
/**
 * component_mobile_ui_fastimage view
 *
 * @author hongliang
 * @copyright 2012-2014 Appbyme
 */
?>
<div class="content-list-ui">
    <img src="<?php echo $this->rootUrl; ?>/images/admin/tmp/fastimage.png" style="width:336px;height: 498px;">
</div>