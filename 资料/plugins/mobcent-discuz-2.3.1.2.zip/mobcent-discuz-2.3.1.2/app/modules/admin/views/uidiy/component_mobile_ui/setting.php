    <?php 
/**
 * component_mobile_ui_setting view
 *
 * @author hongliang
 * @copyright 2012-2014 Appbyme
 */
?>

    <style type="text/css">
        .msg-list {
            position: relative;
            height: 520px;
            overflow-x: hidden;
            overflow-y: auto;
        }
        .setting {
            position: relative;
            left: 0px;
            z-index: 1;
            width:336px;
            height: 493px;
        }
        .switch1 {
            position: absolute;
            z-index: 3;
            margin-top: -470px;
            margin-left: 235px;
        }
        .switch2 {
            position: absolute;
            z-index: 3;
            margin-top: -422px;
            margin-left: 235px;
        }
        .switch3 {
            position: absolute;
            z-index: 3;
            margin-top: -374px;
            margin-left: 235px;
        }
        .switch4 {
            position: absolute;
            z-index: 3;
            margin-top: -326px;
            margin-left: 235px;
        }
        .switch5 {
            position: absolute;
            z-index: 3;
            margin-top: -279px;
            margin-left: 235px;
        }
        .switch6 {
            position: absolute;
            z-index: 3;
            margin-top: -231px;
            margin-left: 235px;
        }
    </style>

    <div class="content-list-ui">
        <img class="setting" src="<?php echo $this->rootUrl; ?>/images/admin/tmp/setting.jpg">
        <!--<div class="switch1">
            <input  name="my-checkbox" type="checkbox" checked data-size="mini"/>
        </div>
        <div class="switch2">
            <input  name="my-checkbox" type="checkbox" checked data-size="mini"/>
        </div>
        <div class="switch3">
            <input  name="my-checkbox" type="checkbox" checked data-size="mini"/>
        </div>
        <div class="switch4">
            <input  name="my-checkbox" type="checkbox" checked data-size="mini"/>
        </div>
        <div class="switch5">
            <input  name="my-checkbox" type="checkbox" checked data-size="mini"/>
        </div>
        <div class="switch6">
            <input  name="my-checkbox" type="checkbox" checked data-size="mini"/>
        </div>-->
    </div>
    <script type="text/javascript">
        //$("[name='my-checkbox']").bootstrapSwitch();
    </script>