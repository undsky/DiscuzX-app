<?php  

/**
 * component_mobile_ui_moduleRef view
 *
 * @author 谢建平 <jianping_xie@aliyun.com>
 * @copyright 2012-2014 Appbyme
 */

?>

<script type="text/javascript">
Appbyme.mainView.renderMobileUI(<?php echo $component['extParams']['moduleId']; ?>);
</script>