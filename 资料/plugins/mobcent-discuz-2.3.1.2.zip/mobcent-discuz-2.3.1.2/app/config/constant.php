<?php

defined('EARTH_RADIUS') or define('EARTH_RADIUS', 6378137);
defined('MINUTE_SECONDS') or define('MINUTE_SECONDS', 60);
defined('HOUR_SECONDS') or define('HOUR_SECONDS', 3600);
defined('DAY_SECONDS') or define('DAY_SECONDS', 86400);

defined('APP_TYPE_ANDROID') or define('APP_TYPE_ANDROID', 1);
defined('APP_TYPE_APPLE') or define('APP_TYPE_APPLE', 5);