<?php

global $_G;
$discuzParams['globals'] = &$_G;

return $discuzParams;