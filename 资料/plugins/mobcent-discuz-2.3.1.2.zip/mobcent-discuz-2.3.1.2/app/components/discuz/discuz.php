<?php

require('discuz_core.php');