<?php 
/**
 * component_mobile_ui_about view
 *
 * @author hongliang
 * @copyright 2012-2014 Appbyme
 */
?>
<div class="content-list-ui">
    <ul class="list-unstyled container-fluid" style="padding-left: 0;padding-right: 0;">
        <li  class="list-group-item" style="height: 65px;"><p class="ull-left text-left" >应用介绍：这是一个神奇的APP，由安米全力打造免费提供给各位用户使用的APP</p></li>
        <li class="list-group-item" style="height: 65px;"><p class="ull-left text-left" style="line-height: 50px;">反馈邮箱：mobcetn@qq.com</p></li>
        <li class="list-group-item" style="height: 65px;"><p class="ull-left text-left" style="line-height: 50px;">官方网站：http://www.appbyme.com</p></li>
        <li class="list-group-item" style="height: 65px;"><p class="ull-left text-left" style="line-height: 50px;">新浪微博：http://weibo.com</p></li>
        <li class="list-group-item" style="height: 65px;"><p class="ull-left text-left" style="line-height: 50px;">腾讯微博：http://t.qq.com</p></li>
        <div style="margin-top:10px;">
            <img src="<?php echo $this->rootUrl; ?>/images/admin/tmp/barcode.jpg" style="width:80px;height: 80px;"/>
            <p>扫扫我</p>
            <p>version 1.0.3 bulid 423e</p>
            <p>扫描二维码即可下载该应用</p>
        </div>
    </ul>
</div>