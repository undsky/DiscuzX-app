<?php

require(dirname(__FILE__) .'/discuz_core.php');