<?php
class Mobcent_upload extends discuz_upload {
}